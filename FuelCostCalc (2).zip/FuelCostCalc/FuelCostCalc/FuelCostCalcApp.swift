//
//  FuelCostCalcApp.swift
//  FuelCostCalc
//
//  Created by Yeabsera Damte on 10/24/24.
//

import SwiftUI

@main
struct FuelCostCalcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
